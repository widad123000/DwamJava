public class Main {
    /**
     * Classe Point du plan avec ses coordonnées x et y
     */
    public class Point extends Object {
        private int x, y;

        // Constructeur par défaut
        public Point() {
            x = 0;
            y = 0;
        }

        // Constructeur avec un seul paramètre (initialisation de l'abscisse)
        public Point(int a) {
            x = a;
            y = 0;
        }

        // Constructeur avec deux paramètres (initialisation de x et y)
        public Point(int a, int b) {
            x = a;
            y = b;
        }

        // Méthode qui affecte la valeur de son paramètre au Point this.
        public void setX(int p) {
            x = p;
        }

        public void setY(int p) {
            y = p;
        }

        public int getX() {
            return x;
        }

        public int getY() {
            return y;
        }

        // Redéfinition de la méthode toString()
        public String toString() {
            return "Point : (" + x + "," + y + ")";
        }
    }

    public void main(String[] args) {

        // Créer un point p avec le constructeur par défaut
        Point p1 = new Point();
        System.out.println("Point p1 : " + p1.toString());

        // Créer un point p2 avec le constructeur à un paramètre
        Point p2 = new Point(3);
        System.out.println("Point p2 : " + p2.toString());

        // Créer un point p3 avec le constructeur à deux paramètres
        Point p3 = new Point(2, 5);
        System.out.println("Point p3 : " + p3.toString());
    }
}