public class Main {
    public static class Point extends Object {
        private int x, y;
        public void setX(int p) {
            x = p;
        }
        public void setY(int p) {
            y = p;
        }
        public int getX() {
            return x;
        }
        public int getY() {
            return y;
        }
    }

    public static void main(String[] args) {

        Point p = new Point();

        p.setX(3);
        p.setY(4);

        System.out.println("Coordonnée x : " + p.getX());
        System.out.println("Coordonnée y : " + p.getY());


    }
    }
