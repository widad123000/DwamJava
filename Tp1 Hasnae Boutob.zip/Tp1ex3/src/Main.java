import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

                Scanner clavier = new Scanner(System.in);

                char monChar = clavier.next().charAt(0);
                System.out.println(monChar);
            }
}