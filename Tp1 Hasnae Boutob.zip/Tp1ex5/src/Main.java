import java.lang.String;
public class Main {
    public static void main(String[] args) {
//String to Integer
        String str = "123";
        Integer I = Integer.valueOf(str); // Utilisation de valueOf()
        System.out.println(str);
//String to int
        String strg = "456";
        int i = Integer.parseInt(strg);
        System.out.println(strg);
//Integer to int
        Integer In = Integer.valueOf(857);
        int j = In.intValue();
        System.out.println(In);
//int to Integer
        int p = 58;
        Integer K = Integer.valueOf(p);
        System.out.println(p);
//int to String
        int r = 87;
        String S = String.valueOf(r);
        System.out.println(r);
//Integer to string
        Integer H = Integer.valueOf(478);
        String E = String.valueOf(H);
        System.out.println(H);
    }
}