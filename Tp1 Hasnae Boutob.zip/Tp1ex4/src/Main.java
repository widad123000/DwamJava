import java.util.Calendar;
public class Main {
    public static void main(String[] args) {
        Calendar rightNow = Calendar.getInstance();
        System.out.println(rightNow);

    }
}