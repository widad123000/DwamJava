public class Main {
    public static void modifVal(int x) {
        x = x + 200;
        // La valeur de x est modifiée, mais cela n'affecte pas la variable d'origine dans la méthode appelante.
        System.out.println(x);
    }
    public static void modifObj(int p[]) {
        p[0] = p[0] + 200;
        System.out.println(p[0]);
        // La référence au tableau est modifiée, donc la modification est visible à l'extérieur.
    }


    public static void main(String[] args) {
       modifVal(5);

    }
}