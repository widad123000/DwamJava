import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Entrer Votre nom :");
        String nom = scanner.nextLine();
        System.out.println("Entrer votre age :" );
        int age = scanner.nextInt();

        System.out.println("Votre nome est "+nom+" et votre age est "+age );
    }
}