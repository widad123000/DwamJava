public class Marcheur implements Loisir {
    public void courirOuMarcher(){
        System.out.println("Moi je marche"+distance+" Km.");
    }
}
