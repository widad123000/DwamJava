public  class Main{
    public  static void main (String args[]){
 Coureur c = new Coureur();
         c.courirOuMarcher();
         c.courirMoins();
         Loisir c1 = new Coureur();
                 c1.courirOuMarcher();
Marcheur C = new Marcheur();
        C.courirOuMarcher();
    }
}