package tp8;

public class TestPoint {
    static public void main(String[] args){
        Point point = new Point();
        Point point2 = new Point();

        System.out.println(point.convText());

        System.out.println(point.compare(point2));
    }
}
