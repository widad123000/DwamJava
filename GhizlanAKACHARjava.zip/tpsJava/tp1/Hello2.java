package tp1;

public class Hello2 {
    static public void main(String[] args){
        if (args.length !=0)
        System.out.println("Hello " + args[0]);
        }
       
}
