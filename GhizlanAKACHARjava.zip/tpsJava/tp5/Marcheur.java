package tp5;

public class Marcheur implements Loisire {
    public void courirOuMarcher(){
        System.out.println("Moi, je march... ");
    }
}
