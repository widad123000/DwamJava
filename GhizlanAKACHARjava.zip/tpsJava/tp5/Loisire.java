package tp5;

/**
 * Loisire
 */
public interface Loisire {
    public final int distance = 21;
    public void courirOuMarcher();
}