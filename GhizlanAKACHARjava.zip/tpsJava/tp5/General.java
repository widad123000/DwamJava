package tp5;

abstract class General {
    public int x = 2;

    abstract public void qui(); // abstract method

    public void moi(){
        System.out.println("Mehode general ");
    }
}
