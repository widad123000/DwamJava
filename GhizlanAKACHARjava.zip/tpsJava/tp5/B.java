package tp5;

public interface B {
    int x = 2;
    public void f();
}
