package tpn5;

public interface ILoisir {
	public int distance=21 ;
	public void CourirOuMarcher();
	
}
