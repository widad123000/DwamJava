package tpn5;

public class Marcheur implements ILoisir {
	public void CourirOuMarcher() {
		System.out.println("je marche "+ distance + " km");
	}

}
