package tpn3jee;

import java.util.ArrayList;
import java.util.List;

public class GestionEtudiants {
	private static List<Etudiant> listeEtudiants = new ArrayList<>();
}
