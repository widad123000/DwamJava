package tpn3jee;

public class Etudiant {

}
