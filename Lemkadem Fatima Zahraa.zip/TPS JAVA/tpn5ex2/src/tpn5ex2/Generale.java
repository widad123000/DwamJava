package tpn5ex2;

 abstract class Generale {
	public int x=2;
	public abstract  void qui();
	public void moi() {
		System.out.println("Méthode Générale");
	}
	
	

}
