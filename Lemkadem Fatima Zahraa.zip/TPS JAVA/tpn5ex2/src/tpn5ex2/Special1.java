package tpn5ex2;

public class Special1 extends Generale {
	public void qui() {
		System.out.println("C'est la classe Special de General ");
	}
	public void moi() {
		  System.out.println("message de classe Speciale a place de Generale");
	}
	
}
