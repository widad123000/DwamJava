package tpn5ex2;

public class Test {
	public static void main(String [] args) {
		Special1 S = new Special1() ;
		S.moi();
		S.qui();
		S.x++;
		System.out.println(S.x);
		
	}
}
