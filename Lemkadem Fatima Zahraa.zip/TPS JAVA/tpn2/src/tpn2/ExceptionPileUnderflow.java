package tpn2;

public class ExceptionPileUnderflow extends RuntimeException {
	public ExceptionPileUnderflow(String message )
	{
		super(message);
	}
}
