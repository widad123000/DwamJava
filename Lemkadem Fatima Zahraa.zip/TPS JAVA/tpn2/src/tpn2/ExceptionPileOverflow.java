package tpn2;

public class ExceptionPileOverflow extends RuntimeException{
	public  ExceptionPileOverflow(String message) {
		super(message);
	}
	

}
