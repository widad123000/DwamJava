package tpn4;

public class ArticleLuxe extends Article {
	public ArticleLuxe(int numero , String designation , double prix , int qte ) {
		super(numero , designation , prix , qte);
	}

}
