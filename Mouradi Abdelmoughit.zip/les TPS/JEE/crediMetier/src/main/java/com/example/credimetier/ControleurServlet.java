package com.example.credimetier;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//@WebServlet(name = "ControleurServlet", urlPatterns = "/control")
public class ControleurServlet extends HttpServlet {
    private  CreditMetierImpl metier;
    @Override
    public void init() throws ServletException {
        metier = new CreditMetierImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("creditModel",new ModelCredit());
        req.getRequestDispatcher("/vueCredit.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      double montant = Double.parseDouble(req.getParameter("montant"));
      double taux = Double.parseDouble(req.getParameter("taux"));
      int duree = Integer.parseInt(req.getParameter("duree"));
       ModelCredit model1 = new ModelCredit();
       model1.setMontant(montant);
        model1.setTaux(taux);
        model1.setDuree(duree);
       double res = metier.calculerMesualiteCredit(montant,taux,duree);
       model1.setMensuali(res);
        req.setAttribute("creditModel",model1);
       req.getRequestDispatcher("vueCredit.jsp").forward(req,resp);

    }
}
