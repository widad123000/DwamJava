package com.example.credimetier;

public interface CreditMetier {
    public double calculerMesualiteCredit(double capital,double taux,int duree);
}
