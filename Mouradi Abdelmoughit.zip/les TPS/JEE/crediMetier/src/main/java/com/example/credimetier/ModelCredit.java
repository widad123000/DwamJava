package com.example.credimetier;

public class ModelCredit {
      private double montant;
      private double taux;
      private int duree;
      private double mensuali;
      public ModelCredit()
      {
          super();
      }
      public ModelCredit(double montant,double taux,int duree,double mensuali){
          this.montant = montant;
          this.duree = duree;
          this.taux = taux;
          this.mensuali = mensuali;
      }

    public double getMontant() {
        return montant;
    }

    public double getTaux() {
        return taux;
    }

    public int getDuree() {
        return duree;
    }

    public double getMensuali() {
        return mensuali;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }

    public void setTaux(double taux) {
        this.taux = taux;
    }

    public void setMensuali(double mensuali) {
        this.mensuali = mensuali;
    }

}
