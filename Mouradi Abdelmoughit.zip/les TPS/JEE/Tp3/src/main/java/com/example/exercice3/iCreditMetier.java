package com.example.exercice3;
 public  interface iCreditMetier  {
     public  double calculerMesualiteCredit(double capitale,double taux, int duree);
}