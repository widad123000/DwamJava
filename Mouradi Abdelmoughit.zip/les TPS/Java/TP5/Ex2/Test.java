public class Test {
    static public void main(String args[]){
    Speciale1 s = new Speciale1();
    s.moi();
    s.qui();
    s.x++;
    System.out.println(s.x);
    ConcreteC c = new ConcreteC();
        c.methodA();
        c.methodB();
 }

}
