public class Marcheur implements Loisir {
    @Override
     public void courirOuMarcher(){
        System.out.println("Moi, je marche...");
     }
    
}
