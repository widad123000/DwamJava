
interface Loisir {
 public int distance = 21;
 public void courirOuMarcher();
}