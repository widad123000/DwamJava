public class Point {
    private float x, y;
    private static int count = 0;  // Compteur d'objets créés

    public Point(float x, float y) {
        this.x = x;
        this.y = y;
        count++;
    }

    public void deplace(float dx, float dy) {
        x += dx;
        y += dy;
    }

    public void affiche() {
        System.out.println("Coordonnées du point : (" + x + ", " + y + ")");
        System.out.println("Nombre d'objets créés de type point : " + count);
    }

    public static void main(String[] args) {
        Point p1 = new Point(1.0f, 2.0f);
        Point p2 = new Point(3.0f, 4.0f);

        p1.affiche();
        p2.affiche();
    }
}
