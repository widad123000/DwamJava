import java.util.Arrays;

public class Ensemble {
    private static final int MAX_SIZE = 50;
    private String[] tab;
    private int size;

    public Ensemble() {
        this.tab = new String[MAX_SIZE];
        this.size = 0;
    }

    public Ensemble(int n) {
        this.tab = new String[n];
        this.size = 0;
    }

    public Ensemble(Ensemble other) {
        this.tab = Arrays.copyOf(other.tab, other.size);
        this.size = other.size;
    }

    public void remplir() {
        // Implement the remplir method as needed
    }

    public void afficher() {
        // Implement the afficher method as needed
    }

    public boolean est_membre(String x) {
        // Implement the est_membre method as needed
        return false;
    }

    public void ajouter(String x) {
        // Implement the ajouter method as needed
    }

    public void supprimer(String x) {
        // Implement the supprimer method as needed
    }

    public void copier(Ensemble other) {
        this.tab = Arrays.copyOf(other.tab, other.size);
        this.size = other.size;
    }

    public boolean est_egal(Ensemble other) {
        // Implement the est_egal method as needed
        return false;
    }

    public void vider() {
        // Implement the vider method as needed
    }

    // Functions independent of the Ensemble class
    public static void vider(Ensemble ens) {
        ens.vider();
    }

    public static boolean est_egal(Ensemble ens1, Ensemble ens2) {
        return ens1.est_egal(ens2);
    }

    public static void main(String[] args) {
        // Test the various methods here
    }
}
