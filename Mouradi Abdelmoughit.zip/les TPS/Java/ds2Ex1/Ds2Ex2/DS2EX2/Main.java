package DS2EX2;
import org.w3c.dom.Node;

import DS2EX2.parti2.Compte;
import DS2EX2.parti2.ListeChainee;

public class Main {
     public static void main(String[] args) {
        ListeChainee liste = new ListeChainee();

        liste.insertLast(new Compte("123", 1000.0, "Actif"));
        liste.insertLast(new Compte("456", 2000.0, "Inactif"));
        liste.insertFirst(new Compte("789", 1500.0, "Actif"));
        liste.insertAt(new Compte("999", 3000.0, "Actif"), 1);

        System.out.println("Liste initiale :");
        displayList(liste);

        liste.deleteLast();
        liste.deleteFirst();
        liste.deleteAt(1);

        System.out.println("\nListe après suppression :");
        displayList(liste);

        System.out.println("\nÉlément à l'index 0 : " + liste.get(0));
        System.out.println("Taille de la liste : " + liste.getSize());
        System.out.println("Taille de la liste (version récursive) : " + liste.getSizeRecursive());
    }

    private static void displayList(ListeChainee liste) {
        Node current = liste.head;
        while (current != null) {
            System.out.println("RIB: " + current.data.RIB + ", Solde: " + current.data.solde + ", État: " + current.data.etat);
            current = current.next;
        }
    }
}
