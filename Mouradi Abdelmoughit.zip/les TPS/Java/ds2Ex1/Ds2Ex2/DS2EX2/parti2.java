package DS2EX2;

public class parti2 { 
class Compte {
    String RIB;
    double solde;
    String etat;

    public Compte(String RIB, double solde, String etat) {
        this.RIB = RIB;
        this.solde = solde;
        this.etat = etat;
    }
}

class Node {
    Compte data;
    Node next;

    public Node(Compte data) {
        this.data = data;
        this.next = null;
    }
}

class ListeChainee {
    private Node head;

    // Fonction insertLast
    public void insertLast(Compte compte) {
        Node newNode = new Node(compte);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    // Fonction insertFirst
    public void insertFirst(Compte compte) {
        Node newNode = new Node(compte);
        newNode.next = head;
        head = newNode;
    }

    // Fonction insertAt
    public void insertAt(Compte compte, int index) {
        Node newNode = new Node(compte);
        if (index == 0) {
            newNode.next = head;
            head = newNode;
            return;
        }
        Node current = head;
        for (int i = 0; i < index - 1 && current != null; i++) {
            current = current.next;
        }
        if (current == null) {
            return;
        }
        newNode.next = current.next;
        current.next = newNode;
    }

    // Fonction deleteLast
    public void deleteLast() {
        if (head == null || head.next == null) {
            head = null;
            return;
        }
        Node current = head;
        while (current.next.next != null) {
            current = current.next;
        }
        current.next = null;
    }

    // Fonction deleteFirst
    public void deleteFirst() {
        if (head != null) {
            head = head.next;
        }
    }

    // Fonction deleteAt
    public void deleteAt(int index) {
        if (index == 0 && head != null) {
            head = head.next;
            return;
        }
        Node current = head;
        for (int i = 0; i < index - 1 && current != null; i++) {
            current = current.next;
        }
        if (current == null || current.next == null) {
            return;
        }
        current.next = current.next.next;
    }

    // Fonction get
    public Compte get(int index) {
        Node current = head;
        for (int i = 0; i < index && current != null; i++) {
            current = current.next;
        }
        return current != null ? current.data : null;
    }

    // Fonction getSize (version 1)
    public int getSize() {
        int size = 0;
        Node current = head;
        while (current != null) {
            size++;
            current = current.next;
        }
        return size;
    }

    // Fonction getSize (version 2 - récursive)
    public int getSizeRecursive() {
        return getSizeRecursiveHelper(head);
    }

    private int getSizeRecursiveHelper(Node node) {
        if (node == null) {
            return 0;
        }
        return 1 + getSizeRecursiveHelper(node.next);
    }
}


 }