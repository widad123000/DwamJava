    import java.util.Scanner;

public class Ex3 {


    public static void main(String args[]) {
        Scanner clavier = new Scanner(System.in);
        System.out.print("Donner entier: ");
        int n = clavier.nextInt();
        System.out.println(n * 2);
    
}

    
}
