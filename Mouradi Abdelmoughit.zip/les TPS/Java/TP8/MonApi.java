interface MonApi {
    // l interface mon api
    public void print();
    public String convTexte();
    public int compare(Object o);
    
}

