package mm;

import java.util.ArrayList;
import java.util.List;

public class GestionEtudiants {
    private static List<Etudiant> listeEtudiants = new ArrayList<>();

    static {
        ajouterEtudiant(new Etudiant("1", "Etudiant1", 15.5, "image1.jpg"));
        ajouterEtudiant(new Etudiant("2", "Etudiant2", 20.0, "image2.jpg"));
        ajouterEtudiant(new Etudiant("3", "Etudiant3", 18.0, "image3.jpg"));
        ajouterEtudiant(new Etudiant("4", "Etudiant4", 13.0, "image4.jpg"));
        ajouterEtudiant(new Etudiant("5", "Etudiant5", 19.0, "image5.jpg"));
        ajouterEtudiant(new Etudiant("6", "Etudiant6", 16.0, "image6.jpg"));
    }


    public static List<Etudiant> getListeEtudiants() {
        return listeEtudiants;
    }

    public static void ajouterEtudiant(Etudiant etudiant) {
        listeEtudiants.add(etudiant);
    }
}
