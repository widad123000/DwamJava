package mm;

public class Etudiant {
    private String cin;
    private String nom;
    private double moyenne;
    private String image;

    public Etudiant(String cin, String nom, double moyenne, String image) {
        this.cin = cin;
        this.nom = nom;
        this.moyenne = moyenne;
        this.image = image;
    }

    public String getCin() {
        return cin;
    }

    public String getNom() {
        return nom;
    }

    public double getMoyenne() {
        return moyenne;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Etudiant etudiant = (Etudiant) obj;
        return cin.equals(etudiant.cin);
    }

    public String getImage() {
        return image;
    }
}
