package mm;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AffichageEtudiants extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<Etudiant> listeEtudiants = GestionEtudiants.getListeEtudiants();

       
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        
        out.println("<html><body>");
        out.println("<h2>Liste des Etudiants</h2>");

        
        for (int i = 1; i <= listeEtudiants.size(); i++) {
            Etudiant etudiant = listeEtudiants.get(i - 1);
            out.println("<p>Nom Etudiant" + i + ": " + etudiant.getNom() + "</p>");
            out.println("<p>CIN " + i + ": " + etudiant.getCin() + "</p>");
            out.println("<p>Moyenne " + i + ": " + etudiant.getMoyenne() + "</p>");
            out.println("<hr>");
        }

        out.println("</body></html>");
    }
}
