package mm;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ex2 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    //http://localhost:8080/TP3/ex4
    
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Récupération de la liste des étudiants
        List<Etudiant> listeEtudiants = GestionEtudiants.getListeEtudiants();

        // Paramètres de la réponse HTTP
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Génération de la page Web dynamique
        out.println("<html><body>");
        out.println("<h2>Liste des Etudiants</h2>");

        // Affichage des étudiants sous forme de liste à puces
        out.println("<ul>");
        for (int i = 1; i <= listeEtudiants.size(); i++) {
            Etudiant etudiant = listeEtudiants.get(i - 1);
            out.println("<li>nom Etudiant" + i + ": " + etudiant.getNom() + ", cin " + i + ": " + etudiant.getCin() + ", moyenne " + i + ": " + etudiant.getMoyenne() + "</li>");
        }
        out.println("</ul>");

        out.println("</body></html>");
    }
}
