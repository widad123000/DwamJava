package m;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Moyennes extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Exemple avec trois étudiants et leurs moyennes
        String[] noms = {"Étudiant1", "Étudiant2", "Étudiant3"};
        double[] moyennes = {15.5, 18.0, 12.8};

        // Afficher les noms et les moyennes
        out.println("<html><body>");
        out.println("<table border='1'>");
        out.println("<tr><th>Nom</th><th>Moyenne</th></tr>");
        for (int i = 0; i < noms.length; i++) {
            out.println("<tr><td>" + noms[i] + "</td><td>" + moyennes[i] + "</td></tr>");
        }
        out.println("</table>");
        out.println("</body></html>");
    }
}

/*import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Moyennes extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int nombreEtudiants = 5; // Nombre d'étudiants
        String[] noms = new String[nombreEtudiants];
        double[] moyennes = new double[nombreEtudiants];

        // Générer aléatoirement les noms et les moyennes
        for (int i = 0; i < nombreEtudiants; i++) {
            noms[i] = "Étudiant" + (i + 1);
            moyennes[i] = Math.random() * 20; // Générer une moyenne aléatoire entre 0 et 20
        }

        // Afficher les noms et les moyennes
        out.println("<html><body>");
        out.println("<table border='1'>");
        out.println("<tr><th>Nom</th><th>Moyenne</th></tr>");
        for (int i = 0; i < nombreEtudiants; i++) {
            out.println("<tr><td>" + noms[i] + "</td><td>" + moyennes[i] + "</td></tr>");
        }
        out.println("</table>");
        out.println("</body></html>");
    }
}
*/