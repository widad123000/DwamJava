class MaPile implements Pile {
    private StringBuilder s;

    public MaPile() {
        s = new StringBuilder();
    }

    public void empiler(char c) {
        s.append(c);
    }

    public char sommet() {
        if (!vide()) {
            return s.charAt(s.length() - 1);
        }
        throw new IllegalStateException("La pile est vide");
    }

    public void depiler() {
        if (!vide()) {
            s.deleteCharAt(s.length() - 1);
        } else {
            throw new IllegalStateException("La pile est vide");
        }
    }

    public boolean vide() {
        return s.length() == 0;
    }

    public boolean pleine() {
        return false;
    }
}