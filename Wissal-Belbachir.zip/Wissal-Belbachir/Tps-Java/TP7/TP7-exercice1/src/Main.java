import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Pile pile = new MaPile();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Entrez des caractères (terminer avec '#') :");

        String input = scanner.nextLine();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == '#') {
                break;
            }
            pile.empiler(c);
        }

        System.out.println("Caractères en ordre inverse :");
        while (!pile.vide()) {
            System.out.print(pile.sommet());
            pile.depiler();
        }
    }
}