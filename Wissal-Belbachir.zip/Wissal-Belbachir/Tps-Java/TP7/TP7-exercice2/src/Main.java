public class Main {
    public static void main(String[] args) {
        TaPile stack = new TaPile(5);

        stack.push('A');
        stack.push('B');
        stack.push('C');

        System.out.println("Stack size: " + stack.size());
        System.out.println("Top element: " + stack.peek());

        System.out.println("Popped element: " + stack.pop());
        System.out.println("Popped element: " + stack.pop());

        System.out.println("Stack size: " + stack.size());
        System.out.println("Top element: " + stack.peek());
    }
}