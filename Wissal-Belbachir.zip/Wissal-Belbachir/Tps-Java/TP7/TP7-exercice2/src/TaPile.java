public class TaPile {
    private char[] stackArray;
    private int top;

    public TaPile(int capacity) {
        stackArray = new char[capacity];
        top = -1;
    }

    public void push(char item) {
        if (top == stackArray.length - 1) {
            System.out.println("Stack Overflow");
        } else {
            top++;
            stackArray[top] = item;
        }
    }

    public char pop() {
        if (top == -1) {
            System.out.println("Stack Underflow");
            return '\0';
        } else {
            char item = stackArray[top];
            top--;
            return item;
        }
    }

    public char peek() {
        if (top == -1) {
            System.out.println("Stack is empty");
            return '\0';
        } else {
            return stackArray[top];
        }
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public int size() {
        return top + 1;
    }
}