public class Polymorph {
    public static void main(String args[]) {
        Article[] chariot = {
                new Article(1, "Pomme", 10, 100),
                new ArticleLuxe(2, "iPhone", 200, 100),
                new Vetement(3, "Pull", 30, 100, 5, "Vert")
        };

        double montant = 0;
        for (Article p : chariot) {
            montant += p.prixTTC();
        }

        System.out.println("Montant total à payer : " + montant);
    }
}
