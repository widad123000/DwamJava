public class Vetement extends Article {
    private int taille;
    private String couleur;

    public Vetement(int numero, String designation, double prixHT, int qte, int taille, String couleur) {
        super(numero, designation, prixHT, qte);
        this.taille = taille;
        this.couleur = couleur;
    }

    // Méthode d'accès (getter) pour la taille
    public int getTaille() {
        return taille;
    }

    // Méthode d'accès (getter) pour la couleur
    public String getCouleur() {
        return couleur;
    }
}
