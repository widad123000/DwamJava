public class Main {
    public static void main(String[] args) {
        Article articleNormal = new Article(1, "Pomme", 10, 100);
        ArticleLuxe articleLuxe = new ArticleLuxe(2, "iPhone", 200, 100);

        afficherPrixTTC(articleNormal);
        afficherPrixTTC(articleLuxe);
    }

    // Méthode paramétrée par un objet Article et affiche son prix TTC
    public static void afficherPrixTTC(Article article) {
        System.out.println("Prix TTC de l'article : " + article.prixTTC());
    }
}
