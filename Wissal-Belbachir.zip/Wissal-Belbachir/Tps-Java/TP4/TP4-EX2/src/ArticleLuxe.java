public class ArticleLuxe extends Article {
    public ArticleLuxe(int numero, String designation, double prixHT, int qte) {
        super(numero, designation, prixHT, qte);
    }

    // Redéfinition de la méthode prixTTC pour prendre en compte la TVA de 25%
    @Override
    public double prixTTC() {
        return super.prixTTC() * 1.25;
    }
}
