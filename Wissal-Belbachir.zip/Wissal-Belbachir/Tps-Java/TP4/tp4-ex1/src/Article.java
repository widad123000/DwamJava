public class Article {
    private static int compteur = 0;

    private int numero;
    private String designation;
    private double prixHT;
    private int qte;

    // Constructeur par défaut
    public Article() {
        this.numero = compteur++;
        this.designation = "spécimen";
        this.prixHT = 1.1;
        this.qte = 222;
    }

    // Constructeur avec paramètres
    public Article(int numero, String designation, double prixHT, int qte) {
        this.numero = numero;
        this.designation = designation;
        this.prixHT = prixHT;
        this.qte = qte;
    }

    // Constructeur de copie
    public Article(Article article) {
        this.numero = article.numero;
        this.designation = article.designation;
        this.prixHT = article.prixHT;
        this.qte = article.qte;
    }

    // Méthode pour calculer le prix TTC
    public double prixTTC() {
        return prixHT * 1.1;
    }

    // Méthodes d'accès (getters)
    public int getNumero() {
        return numero;
    }

    public String getDesignation() {
        return designation;
    }

    public int getQte() {
        return qte;
    }
}
