public class Main {
    public static void main(String[] args) {
        Article a1 = new Article();
        Article a2 = new Article(1, "Pomme", 10.0, 100);
        Article a3 = new Article(a1);

        System.out.println("Article a1 :");
        afficherInfoArticle(a1);

        System.out.println("\nArticle a2 :");
        afficherInfoArticle(a2);

        System.out.println("\nArticle a3 :");
        afficherInfoArticle(a3);
    }

    // Méthode pour afficher les informations d'un article
    public static void afficherInfoArticle(Article article) {
        System.out.println("Numéro : " + article.getNumero());
        System.out.println("Désignation : " + article.getDesignation());
        System.out.println("Prix TTC : " + article.prixTTC());
        System.out.println("Quantité en stock : " + article.getQte());
    }
}
