public class Main {

    public static void main(String[] args) {
        Etudiant etudiant1 = new Etudiant("Alice", 3);
        Etudiant etudiant2 = new Etudiant("Bob", 3);

        etudiant1.Affichage();
        System.out.println("Moyenne de " + etudiant1+ ": " + etudiant1.Moyenne());
        System.out.println(etudiant1+ " est admis : " + etudiant1.Admis());

        etudiant2.Affichage();
        System.out.println("Moyenne de " + etudiant2 + ": " + etudiant2.Moyenne());
        System.out.println(etudiant2+ " est admis : " + etudiant2.Admis());

        System.out.println("Les deux étudiants ont la même moyenne : " + Etudiant.Comparer(etudiant1, etudiant2));

        // Utilisation de la méthode indépendante de la classe
        System.out.println("Les deux étudiants ont la même moyenne (fonction indépendante) : " + Comparer(etudiant1, etudiant2));
    }

    // Méthode indépendante de la classe pour comparer les moyennes de deux étudiants
    public static boolean Comparer(Etudiant etudiant1, Etudiant etudiant2) {
        return etudiant1.Moyenne() == etudiant2.Moyenne();
    }
}