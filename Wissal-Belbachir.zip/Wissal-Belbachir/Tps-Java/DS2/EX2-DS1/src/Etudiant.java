import java.util.Scanner;

public class Etudiant {
    private static int dernierMatricule = 0;

    private int matricule;
    private String nom;
    private int nbrNotes;
    private float[] tabNotes;

    // Constructeur d'initialisation
    public Etudiant() {
        this.matricule = ++dernierMatricule;
        this.nom = "";
        this.nbrNotes = 0;
        this.tabNotes = null;
    }

    // Constructeur avec arguments
    public Etudiant(String nom, int nbrNotes) {
        this.matricule = ++dernierMatricule;
        this.nom = nom;
        this.nbrNotes = nbrNotes;
        this.tabNotes = new float[nbrNotes];
        Saisie();
    }

    // Destructeur
    public void Finalize() {
        System.out.println("L'étudiant " + nom + " avec matricule " + matricule + " a été supprimé.");
    }

    // Constructeur de copie
    public Etudiant(Etudiant autreEtudiant) {
        this.matricule = ++dernierMatricule;
        this.nom = autreEtudiant.nom;
        this.nbrNotes = autreEtudiant.nbrNotes;
        this.tabNotes = new float[nbrNotes];
        System.arraycopy(autreEtudiant.tabNotes, 0, this.tabNotes, 0, nbrNotes);
    }

    // Saisie des notes
    public void Saisie() {
        Scanner scanner = new Scanner(System.in);
        this.tabNotes = new float[nbrNotes];

        System.out.println("Saisie des notes pour l'étudiant " + nom + " (matricule : " + matricule + "):");
        for (int i = 0; i < nbrNotes; i++) {
            System.out.print("Note " + (i + 1) + ": ");
            tabNotes[i] = scanner.nextFloat();
        }
    }

    // Affichage des informations de l'étudiant
    public void Affichage() {
        System.out.println("Matricule: " + matricule);
        System.out.println("Nom: " + nom);
        System.out.println("Nombre de notes: " + nbrNotes);
        System.out.print("Notes: ");
        for (float note : tabNotes) {
            System.out.print(note + " ");
        }
        System.out.println();
    }

    // Calcul de la moyenne des notes
    public float Moyenne() {
        float somme = 0;
        for (float note : tabNotes) {
            somme += note;
        }
        return somme / nbrNotes;
    }

    // Vérification si l'étudiant est admis
    public boolean Admis() {
        return Moyenne() >= 12;
    }

    // Comparaison des moyennes de deux étudiants (méthode de la classe)
    public static boolean Comparer(Etudiant etudiant1, Etudiant etudiant2) {
        return etudiant1.Moyenne() == etudiant2.Moyenne();
    }
}