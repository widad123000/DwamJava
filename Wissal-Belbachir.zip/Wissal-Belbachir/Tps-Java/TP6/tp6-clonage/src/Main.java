
public class Main {
    public static void main(String[] args) {
        Cellule x = new Cellule(0, new int[]{0, 0}); // x Objet Cellule
        x.afficher();
        Cellule y = (Cellule) x.clone(); // y clone de x
        y.afficher();

        x.changeMe();
        x.afficher();
        y.afficher();
    }
}
/*difference :
La principale différence réside dans l'objectif :
le constructeur est utilisé pour créer un nouvel objet et l'initialiser,
tandis que clone() est utilisé pour créer une copie d'un objet existant.
Le clonage permet de créer une copie indépendante de l'objet existant,
 tandis qu'un constructeur crée un nouvel objet avec des valeurs initiales.
Le clonage peut être utilisé pour effectuer des affectations d'objets avec une copie,
mais cela doit être fait avec soin pour éviter des références partagées non souhaitées.
 */