public class Cellule implements Cloneable {
    private int i;
    private int[] t;

    public Cellule(int i, int[] t) {
        this.i = i;
        this.t = t.clone();
    }

    public void changeMe() {
        i = 10;
        t[0] = 11;
        t[1] = 12;
    }

    @Override
    public Object clone() {
        try {
            Cellule tmp = (Cellule) super.clone();
            tmp.t = this.t.clone();
            return tmp;
        } catch (CloneNotSupportedException e) {
            throw new InternalError();
        }
    }

    public void afficher() {
        System.out.println(i + " " + t[0] + " " + t[1]);
    }
}

