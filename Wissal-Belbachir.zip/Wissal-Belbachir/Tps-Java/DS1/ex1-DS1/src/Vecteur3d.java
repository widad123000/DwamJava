public class Vecteur3d {
    private float x, y, z;

    // Constructeur par défaut
    public Vecteur3d() {
        this.x = 0;
        this.y = 0;
        this.z = 0;
    }

    // Constructeur avec des valeurs spécifiées
    public Vecteur3d(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    // Affichage des composantes du vecteur
    public void afficher() {
        System.out.println("(" + x + ", " + y + ", " + z + ")");
    }

    // Somme de deux vecteurs
    public static Vecteur3d somme(Vecteur3d v1, Vecteur3d v2) {
        return new Vecteur3d(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);
    }

    // Produit scalaire de deux vecteurs
    public static float produitScalaire(Vecteur3d v1, Vecteur3d v2) {
        return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
    }

    // Coincide par valeur
    public boolean coincide(Vecteur3d autre) {
        return this.x == autre.x && this.y == autre.y && this.z == autre.z;
    }

    // Norme du vecteur
    public float norme() {
        return (float) Math.sqrt(x * x + y * y + z * z);
    }

    // Comparaison de normes pour trouver le vecteur avec la plus grande norme (renvoie par valeur)
    public static Vecteur3d normax(Vecteur3d v1, Vecteur3d v2) {
        return (v1.norme() > v2.norme()) ? v1 : v2;
    }

    // Comparaison de normes pour trouver le vecteur avec la plus grande norme (renvoie par adresse)
    public static void normaxParAdresse(Vecteur3d v1, Vecteur3d v2, Vecteur3d resultat) {
        resultat.x = (v1.norme() > v2.norme()) ? v1.x : v2.x;
        resultat.y = (v1.norme() > v2.norme()) ? v1.y : v2.y;
        resultat.z = (v1.norme() > v2.norme()) ? v1.z : v2.z;
    }

    // Comparaison de normes pour trouver le vecteur avec la plus grande norme (renvoie par référence)
    public static Vecteur3d normaxParReference(Vecteur3d v1, Vecteur3d v2) {
        return (v1.norme() > v2.norme()) ? v1 : v2;
    }
}