public class  Main{
public static void main(String[] args) {
        Vecteur3d v1 = new Vecteur3d(1, 2, 3);
        Vecteur3d v2 = new Vecteur3d(4, 5, 6);

        // Affichage des vecteurs
        System.out.println("Vecteur 1 : ");
        v1.afficher();
        System.out.println("Vecteur 2 : ");
        v2.afficher();

        // Somme de deux vecteurs
        Vecteur3d somme = Vecteur3d.somme(v1, v2);
        System.out.println("Somme des vecteurs : ");
        somme.afficher();

        // Produit scalaire de deux vecteurs
        float produitScalaire = Vecteur3d.produitScalaire(v1, v2);
        System.out.println("Produit scalaire des vecteurs : " + produitScalaire);

        // Coincide par valeur
        System.out.println("Coincide par valeur : " + v1.coincide(v2));

        // Normax (renvoie par valeur)
        Vecteur3d vecteurMaxValeur = Vecteur3d.normax(v1, v2);
        System.out.println("Vecteur avec la plus grande norme (renvoyé par valeur) : ");
        vecteurMaxValeur.afficher();

        // Normax (renvoie par adresse)
        Vecteur3d vecteurMaxAdresse = new Vecteur3d();
        Vecteur3d.normaxParAdresse(v1, v2, vecteurMaxAdresse);
        System.out.println("Vecteur avec la plus grande norme (renvoyé par adresse) : ");
        vecteurMaxAdresse.afficher();

        // Normax (renvoie par référence)
        Vecteur3d vecteurMaxReference = Vecteur3d.normaxParReference(v1, v2);
        System.out.println("Vecteur avec la plus grande norme (renvoyé par référence) : ");
        vecteurMaxReference.afficher();
        }
        }