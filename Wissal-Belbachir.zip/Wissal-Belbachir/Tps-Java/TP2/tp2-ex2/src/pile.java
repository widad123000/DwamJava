public class pile {
    private char[] elements;
    private int top;

    public pile(int capacity) {
        elements = new char[capacity];
        top = -1;
    }

    public void empiler(char element) {
        if (top == elements.length - 1) {
            System.out.println("La pile est pleine. Impossible d'empiler l'élément.");
            return;
        }
        top++;
        elements[top] = element;
    }

    public char depiler() {
        if (estVide()) {
            System.out.println("La pile est vide. Impossible de dépiler un élément.");
            return '\0';
        }
        char elementDepile = elements[top];
        top--;
        return elementDepile;
    }

    public boolean estVide() {
        return top == -1;
    }

    public boolean estPleine() {
        return top == elements.length - 1;
    }
}