import java.util.Scanner;
import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Entrez une expression avec des parenthèses (terminez par '#') :");
        String text = scanner.nextLine();
        boolean isBalanced = checkParentheses(text);
        if (isBalanced) {
            System.out.println("L'expression est bien parenthésée.");
        } else {
            System.out.println("L'expression n'est pas bien parenthésée.");
        }
    }

    public static boolean checkParentheses(String text) {
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                if (stack.isEmpty()) {
                    return false;
                }
                stack.pop();
            } else if (c == '#') {
                break;
            }
        }

        return stack.isEmpty();
    }
}