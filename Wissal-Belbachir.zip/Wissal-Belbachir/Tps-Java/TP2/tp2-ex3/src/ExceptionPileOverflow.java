// Exception pour le cas de débordement de pile par en haut (pile pleine)
class ExceptionPileOverflow extends Exception {
    public ExceptionPileOverflow() {
        super("Débordement de pile par en haut (pile pleine)");
    }
}