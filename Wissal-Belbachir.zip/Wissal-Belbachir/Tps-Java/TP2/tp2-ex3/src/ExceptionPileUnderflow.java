class ExceptionPileUnderflow extends Exception {
    public ExceptionPileUnderflow() {
        super("Débordement de pile par en bas (pile vide)");
    }
}
