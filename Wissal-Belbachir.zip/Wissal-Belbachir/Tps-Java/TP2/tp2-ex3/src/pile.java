public class pile {
    static final int MAX = 8;
    char t[];
    int top;

    public pile() {
        // Initialise une pile vide
        t = new char[MAX];
        top = -1;
    }

    public void empiler(char c) throws ExceptionPileOverflow {
        // Empile le caractère donné en paramètre
        if (!estPleine())
            t[++top] = c;
        else
            throw new ExceptionPileOverflow();
    }

    public char sommet() throws ExceptionPileUnderflow {
        // Retourne le caractère au sommet de la pile, si la pile n'est pas vide
        if (!estVide())
            return t[top];
        else
            throw new ExceptionPileUnderflow();
    }

    public void depiler() throws ExceptionPileUnderflow {
        // Dépile le caractère au sommet de la pile, si la pile n'est pas vide
        if (!estVide())
            top--;
        else
            throw new ExceptionPileUnderflow();
    }

    public boolean estVide() {
        // Teste si la pile est vide
        return (top < 0);
    }

    public boolean estPleine() {
        // Teste si la pile est pleine
        return (top == MAX - 1);
    } }