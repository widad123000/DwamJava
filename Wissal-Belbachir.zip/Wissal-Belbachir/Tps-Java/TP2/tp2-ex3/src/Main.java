import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        pile p = new pile();
        char c;

        Scanner clavier = new Scanner(System.in);

        System.out.println("Entrez une chaîne de caractères (terminez par '#') :");

        try {
            pile pile = new pile();
            pile.depiler(); // Simuler une tentative de dépiler sur une pile vide
        } catch (ExceptionPileUnderflow e) {
            System.out.println(e.getMessage());
        }

        try {
            pile pile = new pile();
            for (int i = 0; i < pile.MAX + 1; i++) {
                pile.empiler('A'); // Simuler une tentative d'empiler sur une pile pleine
            }
        } catch (ExceptionPileOverflow e) {
            System.out.println(e.getMessage());
        }

    }
}