import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Pile pile = new Pile();
        Scanner clavier = new Scanner(System.in);

        System.out.println("Entrez une expression contenant des parenthèses (terminez par '#') :");
        String expression = clavier.nextLine();

        try {
            if (verifierParentheses(expression)) {
                System.out.println("L'expression est correctement parenthésée.");
            } else {
                System.out.println("L'expression n'est pas correctement parenthésée.");
            }
        } catch (ExceptionPileUnderflow e) {
            System.out.println("Erreur de débordement de pile par en bas (pile vide).");
        } catch (ExceptionPileOverflow e) {
            System.out.println("Erreur de débordement de pile par en haut (pile pleine).");
        }
    }

    static boolean verifierParentheses(String expression) throws ExceptionPileUnderflow, ExceptionPileOverflow {
        Pile pile = new Pile();

        for (char c : expression.toCharArray()) {
            if (estParenthese(c)) {
                if (estParentheseOuvrante(c)) {
                    pile.empiler(c);
                } else {
                    if (!pile.estVide() && parentheseCorrespondante(pile.sommet(), c)) {
                        pile.depiler();
                    } else {
                        return false;
                    }
                }
            }
        }
        return pile.estVide();
    }

    static boolean estParenthese(char c) {
        return c == '(' || c == ')' || c == '[' || c == ']' || c == '{' || c == '}';
    }

    static boolean estParentheseOuvrante(char c) {
        return c == '(' || c == '[' || c == '{';
    }

    static boolean parentheseCorrespondante(char ouvrante, char fermante) {
        return (ouvrante == '(' && fermante == ')') ||
                (ouvrante == '[' && fermante == ']') ||
                (ouvrante == '{' && fermante == '}');
    }
}
