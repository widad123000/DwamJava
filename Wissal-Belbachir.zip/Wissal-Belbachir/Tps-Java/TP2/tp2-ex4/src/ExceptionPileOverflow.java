
class ExceptionPileOverflow extends Exception {
    public ExceptionPileOverflow() {
        super("Débordement de pile par en haut (pile pleine)");
    }
}
