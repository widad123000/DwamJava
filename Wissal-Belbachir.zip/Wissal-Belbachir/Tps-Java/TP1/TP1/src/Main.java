import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Pile p = new Pile();
        char c;

        Scanner clavier = new Scanner(System.in);

        System.out.println("Entrez une chaîne de caractères (terminez par '#') :");

        String input = clavier.nextLine();

        for (int i = 0; i < input.length(); i++) {
            c = input.charAt(i);
            p.empiler(c);
        }

        System.out.println("Chaîne inversée :");

        while (!p.estVide()) {
            c = p.sommet();
            System.out.print(c);
            p.depiler();
        }
    }
}