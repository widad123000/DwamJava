public class Pile {
    static final int MAX = 8;
    char t[];
    int top;

    public Pile() {
        // Initialise une pile vide
        t = new char[MAX];
        top = -1;
    }

    public void empiler(char c) {
        // Empile le caractère donné en paramètre
        if (!estPleine())
            t[++top] = c;
        else
            System.out.println("Pile pleine");
    }

    public char sommet() {
        // Retourne le caractère au sommet de la pile, si la pile n'est pas vide
        if (!estVide())
            return t[top];
        else {
            System.out.println("La pile est vide");
            return '\0'; // Valeur par défaut si la pile est vide
        }
    }

    public void depiler() {
        // Dépile le caractère au sommet de la pile, si la pile n'est pas vide
        if (!estVide())
            top--;
        else
            System.out.println("La pile est vide, rien à dépiler");
    }

    public boolean estVide() {
        // Teste si la pile est vide
        return (top < 0);
    }

    public boolean estPleine() {
        // Teste si la pile est pleine
        return (top == MAX - 1);
    }
}