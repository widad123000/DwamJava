public class Main {
    public static void main(String[] args) {
        int[] t = {2, 3};
        System.out.println("Avant modif, t[0] = " + t[0]);
        modifObj(t);
        System.out.println("Apres modif, t[0] = " + t[0]);
    }

    public static void modifObj(int p[]) {
        p = new int[] {200, 300, 400}; // p[0] = 200
    }
}