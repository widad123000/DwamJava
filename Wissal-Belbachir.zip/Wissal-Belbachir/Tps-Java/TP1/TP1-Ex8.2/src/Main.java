 public class Main {
    public static void main(String[] args) {
        C o = new C();
        modifObj(o);
        System.out.println("Modified X value: " + o.getX());
    }

    public static void modifObj(C p) {
        p.setX(p.getX() + 200);
    }
}
