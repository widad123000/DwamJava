import java.util.Calendar;

public class Main {
    public static void main(String[] args) {
        Calendar rightNow = Calendar.getInstance();

        // tester les get()
        int j = rightNow.get(Calendar.DAY_OF_MONTH);
        int m = rightNow.get(Calendar.MONTH);
        int y = rightNow.get(Calendar.YEAR);
        System.out.println("On est le: " + j + "/" + (m + 1) + "/" + y);

        String jour = "";
        switch (rightNow.get(Calendar.DAY_OF_WEEK)) {
            case 1:
                jour = "Dimanche";
                break;
            case 2:
                jour = "Lundi";
                break;
            // ... à compléter ...
            case 7:
                jour = "Samedi";
                break;
        }
        System.out.printf("On est le: %s %d/%d/%d%n", jour, j, m + 1, y);

        rightNow.set(Calendar.MONTH, Calendar.FEBRUARY);
        rightNow.set(Calendar.DAY_OF_MONTH, 28);

        j = rightNow.get(Calendar.DAY_OF_MONTH);
        m = rightNow.get(Calendar.MONTH);
        y = rightNow.get(Calendar.YEAR);
        System.out.println("On est le: " + j + "/" + (m + 1) + "/" + y);

        rightNow.add(Calendar.DAY_OF_MONTH, 1);

        j = rightNow.get(Calendar.DAY_OF_MONTH);
        m = rightNow.get(Calendar.MONTH);
        y = rightNow.get(Calendar.YEAR);
        System.out.println("Le lendemain est le: " + j + "/" + (m + 1) + "/" + y);

        // Verify for leap year (2016)
        if (y == 2016 && m == Calendar.FEBRUARY && j == 28) {
            rightNow.add(Calendar.DAY_OF_MONTH, 1);
            j = rightNow.get(Calendar.DAY_OF_MONTH);
            m = rightNow.get(Calendar.MONTH);
            y = rightNow.get(Calendar.YEAR);
            System.out.println("Le lendemain du 28 Février 2016 est le: " + j + "/" + (m + 1) + "/" + y);
        }

        // Verify for non-leap year (2019)
        if (y == 2019 && m == Calendar.FEBRUARY && j == 28) {
            rightNow.add(Calendar.DAY_OF_MONTH, 1);
            j = rightNow.get(Calendar.DAY_OF_MONTH);
            m = rightNow.get(Calendar.MONTH);
            y = rightNow.get(Calendar.YEAR);
            System.out.println("Le lendemain du 28 Février 2019 est le: " + j + "/" + (m + 1) + "/" + y);
        }


                int hour = rightNow.get(Calendar.HOUR_OF_DAY);
                System.out.println("Current hour of the day: " + hour);

                rightNow.add(Calendar.HOUR_OF_DAY, 3);
                hour = rightNow.get(Calendar.HOUR_OF_DAY);
                System.out.println("After adding 3 hours: " + hour);


    }
}