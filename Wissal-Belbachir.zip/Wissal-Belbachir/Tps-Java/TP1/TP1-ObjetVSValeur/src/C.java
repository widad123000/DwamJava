public class C {
    int x; // an integer field

    public int getX() {
        return x;
    }

    public void setX(int p) {
        x = p;
    }
}
