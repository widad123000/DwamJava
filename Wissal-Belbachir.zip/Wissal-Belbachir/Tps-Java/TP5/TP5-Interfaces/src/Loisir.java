public interface Loisir {
public int distance = 21;
public void courirOuMarcher();
        }
        /*Oui, il est possible de déclarer une variable de type Loisir
        et de l'instancier avec un objet Coureur.
         (a):  Loisir c = new Coureur(); est valide et fonctionnera correctement.*/

    /*Cependant, (c) : Loisir l = new Loisir();
     n'est pas valide car une interface ne peut pas être instanciée directement.
     Les interfaces ne définissent que des méthodes et ne peuvent pas être utilisées pour créer des objets. */