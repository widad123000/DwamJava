class Coureur implements Loisir {
    //Implémentation de la méthod courirOuMarcher
    public void courirOuMarcher(){
        System.out.println("Je cours "+distance + " Km" ) ;
    }
    // Nouvelle méthode courirMoins
    public void courirMoins() {
        System.out.println("Je cours " + (distance/2) + " Km.");

    }
};