
interface A {
    void f();
    // Cette ligne générera une erreur si décommentée car les interfaces ne peuvent pas contenir de corps de méthode
    // void g();
    // Déclaration d'une méthode par défaut
    default void g() {
        System.out.println("Implementation par défaut de la méthode g()");
    }
    int x = 5;
}






