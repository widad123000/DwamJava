class C implements A, B {
    @Override
    public void f() {
        System.out.println("Implementation de la méthode f()");
    }
}
/* 7 : Si les deux interfaces déclarent une même méthode f(),
la classe C doit fournir une implémentation pour la méthode f().
Si les deux interfaces déclarent la même constante x,
alors la classe C peut utiliser les constantes d'une interface ou l'autre.*/