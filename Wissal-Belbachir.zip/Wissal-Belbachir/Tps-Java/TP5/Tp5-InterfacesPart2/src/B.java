interface B {
    void f();
    int x = 10;
}