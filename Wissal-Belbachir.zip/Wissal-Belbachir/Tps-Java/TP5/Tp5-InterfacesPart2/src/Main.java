public class Main {
    public static void main(String[] args) {
        C c = new C();
        c.f(); // Appelle la méthode f() de la classe C
        c.g(); // Appelle la méthode g() de l'interface As

        System.out.println(A.x); // Affiche la constante x de l'interface A
        System.out.println(B.x); // Affiche la constante x de l'interface B
    }
}