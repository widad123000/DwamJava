class Speciale1 extends Generale {
    public void qui() {
        // Implementation de qui()
        System.out.println("C'est la sous-classe Speciale1");
    }

    public void moi() {
        System.out.println("Méthode spéciale de la classe Speciale1");
    }
}