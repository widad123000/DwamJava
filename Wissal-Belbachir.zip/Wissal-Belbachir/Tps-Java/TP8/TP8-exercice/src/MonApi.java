interface MonApi {
    // Interface avec des outils pour
    // - imprimer un objet
    // - convertir un objet vers formatimprimable (cf. toString)
    // - comparer deux objets (inférieur, égal,supérieur)

    public void print();
    // Affiche sur l'unité standard desortie
    public String convTexte();
    // Formate un objet vers un texteimprimable
    public int compare (Object o);
    // compare this avec o. retourne -1,0 ou 1
}
