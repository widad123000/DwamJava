class Article implements MonApi {
    private String title;
    private String author;
    private String content;
    private  int numero ;

    public Article(String title, String author, String content) {
        this.title = title;
        this.author = author;
        this.content = content;
    }

    public void print() {
        System.out.println(convTexte());
    }

    public String convTexte() {
        return "Title: " + title + "\nAuthor: " + author + "\nContent: " + content;

    }

    public int compare(Object o) {
        // on compare les numéros par exemple
        Article w = (Article) o; // ! important
        if ( numero >  w.numero)
            return 1;
        else if (numero <  w.numero)
            return -1;
        else
            return 0;
    }
}