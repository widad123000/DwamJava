class Point implements MonApi {
    private int x;
    private int y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void print() {
        System.out.printf("(%d, %d)\n", x, y);
    }

    public String convTexte() {
        return "{x:" + x + ", y:" + y + "}";
    }

    public int compare(Object o) {
        if (o instanceof Point) {
            Point otherPoint = (Point) o;
            // Compare the x-coordinates of the points
            if (this.x < otherPoint.x) {
                return -1;
            } else if (this.x > otherPoint.x) {
                return 1;
            } else {
                // If x-coordinates are equal, compare the y-coordinates
                if (this.y < otherPoint.y) {
                    return -1;
                } else if (this.y > otherPoint.y) {
                    return 1;
                } else {
                    return 0;
                }
            }
        }
        return 0;
    }
}