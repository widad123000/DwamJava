public class Main {
    public static void main(String[] args) {
        Article article1 = new Article("Titre 1", "Auteur 1", "Contenu 1");
        Article article2 = new Article("Titre 2", "Auteur 2", "Contenu 2");

        // Test de la méthode convTexte()
        System.out.println(article1.convTexte());
        System.out.println(article2.convTexte());

        // Test de la méthode compare()
        int result = article1.compare(article2);
        if (result < 0) {
            System.out.println("L'article 1 est inférieur à l'article 2");
        } else if (result > 0) {
            System.out.println("L'article 1 est supérieur à l'article 2");
        } else {
            System.out.println("L'article 1 est égal à l'article 2");
        }
        //3
        MonApi point = new Point(1, 2);
        MonApi article = new Article("Titre", "Auteur", "Contenu");

        point.print();
        article.print();

        String s = point.convTexte();
        String t = article.convTexte();

        System.out.println(s);
        System.out.println(t);
        //4
        MonApi[] p = {point, article};
        for (int i = 0; i < 2; i++) {
            p[i].print();
       //5
            point = article;
            point.print();
        }
        //6
        /*
         on ne peut pas écrire point.compare(article);
         car la méthode compare() de l'interface MonApi ne prend pas un objet de type Article en paramètre.
         Cela entraînera une erreur de compilation.Pour résoudre ce problème,
         vous pouvez soit modifier la signature de la méthode compare() dans l'interface MonApi
         pour prendre un objet de type Article en paramètre,
         soit utiliser une conversion de type pour appeler la méthode compare() de la classe Article directement.
         Il est important de noter que toute modification de la signature de la méthode compare() dans l'interface
         MonApi nécessitera également de mettre à jour toutes les classes qui implémentent cette interface pour fournir
         une implémentation de la méthode compare(Article).

                */

    }
}
