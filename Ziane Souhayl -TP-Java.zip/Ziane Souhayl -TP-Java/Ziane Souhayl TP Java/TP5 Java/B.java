interface B {
    void f();
}
