interface Loisir {
    void courirOuMarcher();
}
