interface A {
    void f();
}
