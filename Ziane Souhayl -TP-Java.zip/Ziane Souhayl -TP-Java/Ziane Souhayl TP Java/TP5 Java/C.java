class C implements A, B {
    @Override
    public void f() {
        System.out.println("Méthode f() implémentée dans C");
    }
}
