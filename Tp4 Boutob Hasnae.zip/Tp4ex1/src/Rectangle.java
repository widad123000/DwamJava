import java.awt.*;

public class Rectangle {
    private final Point hautGauche;
    private final Point basDroite;

    public Rectangle(Point h, Point b) {
        hautGauche = new Point(h);
        basDroite = new Point(b);
    }

    public Point getHautGauche() {
        return hautGauche;
    }

    public Point getBasDroite() {
        return basDroite;
    }

    public void setHautGauche(Point h) {
        hautGauche.setX(h.getX());
        hautGauche.setY(h.getY());
    }

    public void setBasDroite(Point b) {
        basDroite.setX(b.getX());
        basDroite.setY(b.getY());
    }

    public int largeur() {
        return (int) Math.abs(basDroite.getX() - hautGauche.getX());
    }

    public int hauteur() {
        return (int) Math.abs(basDroite.getY() - hautGauche.getY());
    }

    public int aire() {
        return largeur() * hauteur();
    }

    public void agrandir(int dx, int dy) {
        basDroite.setX(basDroite.getX() + dx);
        basDroite.setY(basDroite.getY() + dy);
    }
}

}
