package tp2;

public class exercice3 {
	class ExceptionPileUnderflow extends Exception {
	    public ExceptionPileUnderflow() {
	        super("Débordement de pile par en bas (pile vide)");
	    }
	}

	class ExceptionPileOverflow extends Exception {
	    public ExceptionPileOverflow() {
	        super("Débordement de pile par en haut (pile pleine)");
	    }
	}

	class Pile {
	    private char[] t;
	    private int top;
	    private int capacite;

	    public Pile(int capacite) {
	        this.capacite = capacite;
	        this.t = new char[capacite];
	        this.top = -1;
	    }

	    public boolean estVide() {
	        return top == -1;
	    }

	    public boolean estPleine() {
	        return top == capacite - 1;
	    }

	    public void empiler(char c) throws ExceptionPileOverflow {
	        if (!estPleine()) {
	            top++;
	            t[top] = c;
	        } else {
	            throw new ExceptionPileOverflow();
	        }
	    }

	    public char depiler() throws ExceptionPileUnderflow {
	        if (!estVide()) {
	            char temp = t[top];
	            top--;
	            return temp;
	        } else {
	            throw new ExceptionPileUnderflow();
	        }
	    }

	    public char sommet() throws ExceptionPileUnderflow {
	        if (!estVide()) {
	            return t[top];
	        } else {
	            throw new ExceptionPileUnderflow();
	        }
	    }
	}

	
	public class TestPile {
	    public static void main(String[] args) {
	        Pile maPile = new Pile(5);

	        try {
	            maPile.empiler('A');
	            maPile.empiler('B');
	            maPile.empiler('C');

	            System.out.println("Sommet de la pile : " + maPile.sommet());

	            maPile.depiler();
	            maPile.depiler();
	            maPile.depiler(); 

	        } catch (ExceptionPileUnderflow e) {
	            System.err.println("Erreur : " + e.getMessage());
	        } catch (ExceptionPileOverflow e) {
	            System.err.println("Erreur : " + e.getMessage());
	        }
	    }
	}


}
