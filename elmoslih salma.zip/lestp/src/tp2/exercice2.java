package tp2;
import java.util.Scanner;
	import java.util.Stack;
public class exercice2 {
	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        Stack<Character> pile = new Stack<>();

	        System.out.println("Entrez un texte avec des parenthèses (# pour terminer) : ");

	        char caractere = scanner.next().charAt(0);
	        while (caractere != '#') {
	            if (caractere == '(') {
	                pile.push(caractere);
	            } else if (caractere == ')') {
	                if (!pile.isEmpty()) {
	                    pile.pop(); 
	                } else {
	                    System.out.println("Il y a plus de parenthèses fermantes que d'ouvrantes.");
	                    return;
	                }
	            }

	            caractere = scanner.next().charAt(0);
	        }
	        if (pile.isEmpty()) {
	            System.out.println("L'expression est bien parenthésée.");
	        } else {
	            System.out.println("Il y a plus de parenthèses ouvrantes que de fermantes.");
	        }

	        scanner.close();
	    }
	}


