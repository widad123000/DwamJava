package tp2;
import java.util.Scanner;
	import java.util.Stack;
public class exercice1 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        
	        Stack<Character> pile = new Stack<>();

	        System.out.println("Entrez une chaîne de caractères (# pour terminer) : ");

	        char caractere = scanner.next().charAt(0);

	        
	        while (caractere != '#') {
	            pile.push(caractere);
	            caractere = scanner.next().charAt(0);
	        }

	        
	        System.out.println("Chaîne inversée : ");
	        while (!pile.isEmpty()) {
	            caractere = pile.pop();
	            System.out.print(caractere);
	        }

	        scanner.close();
	    }
	}

	
		
}
