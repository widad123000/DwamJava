class ExceptionPileUnderflow extends Exception {
            public ExceptionPileUnderflow() {
                super("Erreur : débordement de pile par en bas (pile vide)");
            }
        }

        class ExceptionPileOverflow extends Exception {
            public ExceptionPileOverflow() {
                super("Erreur : débordement de pile par en haut (pile pleine)");
            }
        }

        class Pile {
            private int maxSize;
            private char[] t;
            private int top;

            public Pile(int size) {
                maxSize = size;
                t = new char[maxSize];
                top = -1;
            }

            public boolean estVide() {
                return top == -1;
            }

            public boolean estPleine() {
                return top == maxSize - 1;
            }

            public void empiler(char c) throws ExceptionPileOverflow {
                if (!estPleine()) {
                    t[++top] = c;
                } else {
                    throw new ExceptionPileOverflow();
                }
            }

            public char depiler() throws ExceptionPileUnderflow {
                if (!estVide()) {
                    return t[top--];
                } else {
                    throw new ExceptionPileUnderflow();
                }
            }

            public char sommet() throws ExceptionPileUnderflow {
                if (!estVide()) {
                    return t[top];
                } else {
                    throw new ExceptionPileUnderflow();
                }
            }
        }

        public class Main {
            public static void main(String[] args) {
                Pile pile = new Pile(5);

                try {
                    pile.empiler('A');
                    pile.empiler('B');
                    System.out.println("Sommet de la pile : " + pile.sommet());

                    while (!pile.estVide()) {
                        System.out.println("Dépiler : " + pile.depiler());
                    }

                    // Tentative de débordement de pile par en bas
                    // pile.depiler(); // Lèvera ExceptionPileUnderflow

                    // Tentative de débordement de pile par en haut
                    pile.empiler('C');
                    pile.empiler('D');
                    pile.empiler('E');
                    pile.empiler('F');
                    pile.empiler('G');
                    pile.empiler('H'); // Lèvera ExceptionPileOverflow
                } catch (ExceptionPileUnderflow e) {
                    System.out.println(e.getMessage());
                } catch (ExceptionPileOverflow e) {
                    System.out.println(e.getMessage());
                }
            }
        }



