import java.util.Stack;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Stack<Character> pile = new Stack<>();
        Scanner scanner = new Scanner(System.in);
        char c;

        System.out.println("Entrez une expression contenant des parenthèses (terminez par '#') :");

        do {
            c = scanner.next().charAt(0);
            if (c == '(') {

                pile.push(c);
            } else if (c == ')') {

                if (!pile.isEmpty()) {
                    pile.pop();
                } else {

                    System.out.println("Plus de parenthèses fermantes que de parenthèses ouvrantes.");
                    return;
                }
            }

        } while (c != '#');


        if (pile.isEmpty()) {
            System.out.println("L'expression est bien parenthésée.");
        } else {
            System.out.println("Plus de parenthèses ouvrantes que de parenthèses fermantes.");
        }
    }
    }
