public class TestPile {
    Stack<Character> pile = new Stack<>();
    Scanner scanner = new Scanner(System.in);
    char c;

        System.out.println("Entrez une chaîne de caractères (terminez par '#') :");

    // Lecture des caractères et empilement
        do {
        c = scanner.next().charAt(0);
        if (c != '#') {
            pile.push(c);
        }
    } while (c != '#');

    // Dépilement et impression inversée
        System.out.println("Chaîne inversée :");
        while (!pile.isEmpty()) {
        c = pile.pop();
        System.out.print(c);
    }
}
}
