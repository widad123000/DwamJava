
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Article a = new Article(1, "Produit", 10.99, 20);
		a.print(); // Affiche le texte formaté de l'article
		System.out.println("Comparison result: " + a.compare(new Article(2, "Autre produit", 15.5, 45)));
		
		Point p = new Point(1, 2);
		p.print(); // Affiche les coordonnées du point
		System.out.println("Comparison result: " + p.compare(new Point(3, 4)));

		MonApi point = new Point(1, 2);
		MonApi article = new Article(2, "Chemise", 15.5, 45);
		point.print(); // Appelle print() de Point
		article.print(); // Appelle print() de Article
		String s = point.convTexte(); // Appelle convTexte() de Point
		String t = article.convTexte(); // Appelle convTexte() de Article

	}

}
