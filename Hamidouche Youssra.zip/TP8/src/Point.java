
public class Point implements MonApi{
	
	    private int x, y;

	    // Constructeur
	    public Point(int x, int y) {
	        this.x = x;
	        this.y = y;
	    }

	    // Méthode print
	    public void print() {
	        System.out.printf("(%d, %d)\n", x, y);
	    }

	    // Méthode convTexte
	    public String convTexte() {
	        return "{x:" + x + ", y:" + y + "}";
	    }

	    // Méthode compare
	    public int compare(Object o) {
	        Point p = (Point) o;
	        if (x > p.x)
	            return 1;
	        else if (x < p.x)
	            return -1;
	        else
	            return 0;
	    }
	}

