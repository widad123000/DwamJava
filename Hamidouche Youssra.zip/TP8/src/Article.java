
public class Article {

}
