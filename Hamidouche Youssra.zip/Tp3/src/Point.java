
public class Point extends Object {
	/**
	* Classe Point du plan avec ses coordonnées x et y
	*/
	
	    private int x, y;

	    /**
	    * Méthode qui affecte la valeur de son paramètre
	    * au Point this.
	    */ 
	    public void setX(int p) {
	        x = p;
	    }

	    public void setY(int p) {
	        y = p;
	    }

	    public int getX() {
	        return x;
	    }

	    public int getY() {
	        return y;
	    }
	}

}
