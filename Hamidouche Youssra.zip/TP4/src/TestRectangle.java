
public class TestRectangle {
	public class TestRectangle {
	    public static void main(String[] args) {
	        Point point1 = new Point(2, 3);
	        Point point2 = new Point(5, 7);

	        Rectangle rectangle1 = new Rectangle();
	        Rectangle rectangle2 = new Rectangle(point1, point2);

	        rectangle1.afficher();
	        System.out.println("Surface : " + rectangle1.surface());

	        System.out.println();

	        rectangle2.afficher();
	        System.out.println("Surface : " + rectangle2.surface());

	        System.out.println();

	        rectangle2.zoom(2, 2);
	        rectangle2.afficher();
	        System.out.println("Surface : " + rectangle2.surface());
	    }
	}

}
