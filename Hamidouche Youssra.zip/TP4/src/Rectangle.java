
public class Rectangle {
	public class Rectangle {
	    private Point hg, bd; // Les coins haut à gauche

	    // Rectangle par défaut. Choisir son initialisation
	    public Rectangle() {
	        hg = new Point(0, 0);
	        bd = new Point(1, 1);
	    }

	    // Initialisation des coins à partir des paramètres
	    public Rectangle(Point h, Point b) {
	        hg = new Point(h);
	        bd = new Point(b);
	    }

	    // Affiche les coordonnées des coins
	    public void afficher() {
	        System.out.println("HG : (" + hg.getX() + ", " + hg.getY() + ")");
	        System.out.println("BD : (" + bd.getX() + ", " + bd.getY() + ")");
	    }

	    // Calcule de la surface
	    public int surface() {
	        int largeur = Math.abs(bd.getX() - hg.getX());
	        int hauteur = Math.abs(bd.getY() - hg.getY());
	        return largeur * hauteur;
	    }

	    // Dilatation des coordonnées. Delta donné.
	    public void zoom(int deltax, int deltay) {
	        hg.setX(hg.getX() - deltax);
	        hg.setY(hg.getY() - deltay);
	        bd.setX(bd.getX() + deltax);
	        bd.setY(bd.getY() + deltay);
	    }
	    private Point hg, bd;

	    // ...

	    // Méthodes set et get
	    public void setHG(Point p) {
	        hg = new Point(p);
	    }

	    public Point getHG() {
	        return new Point(hg);
	    }

	    public void setBD(Point p) {
	        bd = new Point(p);
	    }

	    public Point getBD() {
	        return new Point(bd);
	    }
	    // Autres méthodes...
	}

}
