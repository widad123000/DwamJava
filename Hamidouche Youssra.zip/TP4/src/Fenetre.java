
public class Fenetre {
	public class Fenetre {
	    private Rectangle rectangle;
	    private String titre;

	    // Constructeur
	    public Fenetre(Rectangle rectangle, String titre) {
	        this.rectangle = rectangle;
	        this.titre = titre;
	    }

	    // Méthodes utiles
	    public void deplacer(int deltax, int deltay) {
	        rectangle.zoom(deltax, deltay);
	    }

	    public void agrandir(int deltax, int deltay) {
	        rectangle.zoom(deltax, deltay);
	    }

	    // Autres méthodes...
	}

}
