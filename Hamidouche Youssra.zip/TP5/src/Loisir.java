

	interface Loisir {
	    int distance = 21; // Constante

	    void courirOuMarcher(); // Méthode abstraite
	    Loisir c = new Coureur(); // (a) Correct
	    Coureur c = new Coureur(); // (b) Correct
	    c.courirMoins(); // Appel de la nouvelle méthode
	    class Marcheur implements Loisir {
	        public void courirOuMarcher() {
	            System.out.println("Moi, je marche...");
	        }
	    }
	    Loisir mesLoisirs[] = { new Marcheur(), new Coureur() };

	    for (Loisir loisir : mesLoisirs) {
	        loisir.courirOuMarcher();
	    }
	    interface A {
	        void f();
	    }

	    interface B {
	        void f();
	    }

	    class C implements A, B {
	        public void f() {
	            // Implémentation de la méthode f
	        }
	    }

	
	
	}

}
