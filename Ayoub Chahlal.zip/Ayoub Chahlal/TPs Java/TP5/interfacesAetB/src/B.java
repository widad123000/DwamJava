public interface B {
    public int x  = 0;
    public void  f();
}
