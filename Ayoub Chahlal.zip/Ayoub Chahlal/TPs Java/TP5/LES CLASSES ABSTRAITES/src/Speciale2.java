class Speciale2 extends Speciale {
    public void qui() {
        System.out.println("C'est la sous-classe Speciale2");
    }

    public void specialMoi() {
        System.out.println("Méthode special Moi avec la classe Speciale2");
    }
}