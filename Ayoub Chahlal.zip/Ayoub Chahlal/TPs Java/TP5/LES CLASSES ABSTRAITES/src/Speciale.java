abstract class Speciale extends Generale {
    abstract public void specialMoi();
}