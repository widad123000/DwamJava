interface Pile {
    final int MAX = 8;


    public void empiler(char c);

    public char sommet();

    public void depiler();

    public boolean vide();

    public boolean pleine();
    StringBuilder s = new StringBuilder(MAX);


};