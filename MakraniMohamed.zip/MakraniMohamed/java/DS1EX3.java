public class Compte {
    private int numero;
    private double solde;
    private String etat;

    public Compte(int numero, double solde, String etat) {
        this.numero = numero;
        this.solde = solde;
        this.etat = etat;
    }

    // Getter and Setter methods
}

public class Noeud {
    public Compte compte;
    public Noeud suivant;

    public Noeud(Compte compte) {
        this.compte = compte;
        this.suivant = null;
    }
}

public class ListeChainee {
    private Noeud tete;

    public ListeChainee() {
        this.tete = null;
    }

    public void insertLast(Compte compte) {
        Noeud nouveauNoeud = new Noeud(compte);
        if (tete == null) {
            tete = nouveauNoeud;
        } else {
            Noeud courant = tete;
            while (courant.suivant != null) {
                courant = courant.suivant;
            }
            courant.suivant = nouveauNoeud;
        }
    }

    // Les autres méthodes à implémenter selon les spécifications
}

public class Main {
    public static void main(String[] args) {
        ListeChainee liste = new ListeChainee();

        Compte compte1 = new Compte(1, 1000.0, "Actif");
        Compte compte2 = new Compte(2, 2000.0, "Inactif");

        liste.insertLast(compte1);
        liste.insertLast(compte2);

        // Testez les autres méthodes ici
    }
}
