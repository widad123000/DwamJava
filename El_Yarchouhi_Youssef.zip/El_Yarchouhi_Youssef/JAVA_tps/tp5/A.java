package tp5;

public interface A {
    int x = 2;
    public void f();
    public void g();
}
