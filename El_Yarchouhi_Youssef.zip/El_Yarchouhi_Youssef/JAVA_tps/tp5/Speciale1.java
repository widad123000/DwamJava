package tp5;

public class Speciale1 extends General{
    
    public void qui(){
        System.out.println("c'est la sous-classe Speciale1");
    }
    // redifine moi()
    public void moi(){
        System.out.println("not a general Mehode");
    }
    
}
