package tp5;

public class C implements A, B{
    
    public void f(){
        System.out.println("this is f()!");
    }
    public void g(){
        System.out.println("this is g()!");
    }
}
