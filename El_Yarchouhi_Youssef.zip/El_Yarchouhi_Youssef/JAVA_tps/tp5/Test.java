package tp5;
import tp5.Loisire;

public class Test {
    static public void main(String[] args){
        // Coureur a = new Coureur();

        //a.courirOuMarcher();

        // exercics 1:
        // Loisire cc = new Coureur();
        // Loisire I = new Loisire();

        // cc.courirMoins();

        // prgram that creates an array 'mesLoisirs' containing objects of type 'Loisire'
        // Loisire[] mesLoisirs = {new Marcheur() , new Coureur()};

        // for (Loisire loisire : mesLoisirs) {
        //     loisire.courirOuMarcher();
        // }
        
        // // check two interfaces to a class
        // A c = new C();
        // c.f();
        // System.out.println(A.x);

        Speciale1 s = new Speciale1();
        s.moi();
        s.qui();
        s.x++;
        System.out.println(s.x);


    }
}