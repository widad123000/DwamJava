
public interface B {
	public int x = 9;
	 public void f();
}
