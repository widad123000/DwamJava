
public class special_CA extends classabstrait {
	
	public void qui() {
		System.out.println("C'est la sous-class special ");
	}
	public void moi() {
		System.out.println("Aouannar douae");
	}

}
