
public class Marcheur implements Loisir {

	public void CourirOuMarcher() {
		
		System.out.println("Moi, je marche ...");
		
	}

}
