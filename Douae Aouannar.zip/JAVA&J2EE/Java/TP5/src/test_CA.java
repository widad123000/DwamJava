
public class test_CA {

	public static void main(String[] args) {
		special_CA s = new special_CA();
		
		s.qui();
		s.moi();
		s.x++;
		System.out.println(s.x);

	}

}
