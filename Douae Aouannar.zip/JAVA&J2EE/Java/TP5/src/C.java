
public class C implements A,B {

	public void f() {
		System.out.println("implementation de f()");
		
	}
	public void g() {
		System.out.println("implementation de g()");
	}

}
