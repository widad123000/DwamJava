
public interface A {
	public int x = 3;
 public void f();
 public void g();
 default void b() { };
}
