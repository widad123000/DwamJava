
abstract class classabstrait {
	public int x=3 ;
	
	abstract public void qui() ;
	
	public void moi() {
		System.out.println("Methode generale");
	}
	

}
