
public class TestC {

	public static void main(String[] args) {
		C c = new C();
		
		c.f();
		
		System.out.println(A.x);
		System.out.println(B.x);
		

	}

}
