
public interface MonApi {

	
	public void print();
	public String ConvText();
	public int Compare(Object o);
}
