
public class methodeparam {
	
	public static void afficheprix(Article a) {
		System.out.println( a.getPrix_HT());
	}

}
