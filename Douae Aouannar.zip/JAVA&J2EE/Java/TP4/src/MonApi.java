
public interface MonApi {
	
	public void print();
	public String convText();
	public int Compare(Object o);

}
