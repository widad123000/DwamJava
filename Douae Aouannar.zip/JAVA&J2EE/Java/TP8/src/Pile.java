
public interface Pile {
	final int MAX =8;
	
	public void empiler(char c);
	public void depiler();
	public char sommet();
	public boolean estVide();
	public boolean estPlein();

}
