package tp5;

public interface A {
	 void f();
	    int x = 10; 
	}

