package tp5;

abstract  class General {
	
	public int x=2; 
	
	abstract public void qui(); 
	
	public void moi(){
		
	System.out.println("Méthode générale");}

}
