package tp5;

public interface Loisir {
	public int distance = 21;
	public void courirOuMarcher();

}
