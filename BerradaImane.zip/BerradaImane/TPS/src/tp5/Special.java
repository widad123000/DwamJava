package tp5;

public class Special extends General {
	
	     public void qui() {
		
		System.out.println("C'est la sous-classe Speciale1");}
	     
		public void moi()
		{
			System.out.println("Méthode générale 2");
		}

}
