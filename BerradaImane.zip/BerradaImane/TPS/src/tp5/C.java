package tp5;
public class C implements A,B{
	 public void f() {
		 System.out.println("class c");
	 }

}
