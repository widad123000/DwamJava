package tp5;

public class Courreur implements Loisir{
	public void courirOuMarcher(){
		System.out.println("Je cours"+distance+" Km.");
		}
	public void courirMoins() {
		//distance /= 2;//
		System.out.println("Je cours"+(distance/2)+" Km.");
		}

}
