package tp5;

public class Marcheur implements Loisir{
	public Marcheur() {
		
	System.out.println("moi je marche");}

	@Override
	public void courirOuMarcher() {
		
		
	}

}
