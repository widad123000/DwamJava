package tp5;

public interface B {
	 void f();
	    int x = 10; 
	}


