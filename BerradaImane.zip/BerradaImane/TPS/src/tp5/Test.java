package tp5;

public class Test {

	public static void main(String[] args) {
		Courreur c=new Courreur();
		c.courirOuMarcher();
		c.courirMoins();
		Loisir a = new Courreur();//c est possible
		a.courirOuMarcher();
		//a.courirMoins();//cette methode nest pas declarer dans loisir
		//Loisir l = new Loisir();  //on ne peut pas instancier avec une interface
		
		Loisir mesLoisirs[] = { new Marcheur(), new Courreur() } ;
		//
		 C  l = new  C ();
	        
	        l.f();
	        System.out.println("A.x: " + A.x);
	        System.out.println("B.x: " + B.x);
	        //
	        Special s = new Special();
	        s.moi();
	        s.qui();
	        s.x++;
	        System.out.println(s.x);
	       
	        
	        
	        
		
	}

}
