package Tp3;

public class Point extends Object{
	float x;
	float y;
	public Point() {
		this.x=0;
		this.y=0;
	}
	 public Point(float x, float y) {
	        this.x = x;
	        this.y = y;
	    }
	    public Point(float x) {
	        this.x = x;
	        this.y = 0;
	    }
	public void setX(float a) {
		x=a;
	}
	public void setY(float b) {
		y=b;
	}
	public float getX() {
		return x;
	}
	public float getY() {
		return y;
	}
    public void reset() {
    	x=0;
    	y=0;
    }
    public void deplacer(int a,int b) {
    	x+=a;
    	y+=b;
    }
    public double distance(Point b) {
    	
    return Math.sqrt(Math.pow((b.getX()-x),2)+Math.pow((b.getY()-y),2));	
    }
    public static double distance (Point a,Point b) {
    	return Math.sqrt(Math.pow((b.getX()-a.getX()),2)+Math.pow((b.getY()-a.getY()),2));
    }
   public boolean equals(Point c)  {
	  
	  if(x==c.x && y==c.y ) 
	  return true;
	  else 
		  return false;
		   
	   
   }
   boolean equal(Object a){
	   return (this.x == ((Point)a).x &&
	   this.y == ((Point)a).y ) ;
	   }
   public String toString() {
	   return "(" + x + "," + y + ")" ;
	   }
   //
        
	public static void main(String[] args) {
		Point p=new Point();
		p.setX(1);
		p.setY(2);
		System.out.println("x="+p.getX());
		System.out.println("y="+p.getY());
		//
		Point b=new Point();
		b.setX(2);
		b.setY(3);
		System.out.println("La distance est "+ p.distance(b));
		//
		Point a=new Point();
		b.setX(4);
		b.setY(5);
		System.out.println("la distance entre a et b est"+Point.distance(a, b));
		//
		System.out.println(p.equals(b));
		System.out.println(p.equal(b));
		//
		p.reset();
		System.out.println(" apres reset x="+p.getX());
		System.out.println(" apres reset y="+p.getY());
		//
		System.out.println(b.toString());
		
	}

}