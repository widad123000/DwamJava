package tp1;

import java.util.Calendar;

public class Calendrier {
	public static void main(String[] args) {
		Calendar rightNow = Calendar.getInstance();
	switch (rightNow.get(Calendar.DAY_OF_WEEK)) {
	case 1:System.out.println("Dimanche");
	case 2:System.out.println("Lundi");
	}
	    

		int d=rightNow.get(Calendar.DAY_OF_MONTH);
				int m = rightNow.get (Calendar.MONTH)+1;
				int y = rightNow.get (Calendar.YEAR);
				rightNow.set(Calendar.MONTH,Calendar.APRIL);
				m = rightNow.get (Calendar.MONTH)+1;
				
				System.out.println(d+"/"+m+"/"+y);
				
				
				

	}

}
