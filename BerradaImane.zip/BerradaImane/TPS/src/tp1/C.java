package tp1;

public class C {
	int x; 
	public int getX()
	{return x;
	}
	public void setX(int p)
	{x = p;
	} 
	//
	public static void main(String[] args) {
	Integer I;
	I = Integer.valueOf("123");
	System.out.println(I);
	int i;
	i = Integer.parseInt("456");
	System.out.println(i);
	int a = 34;
	String s = String.valueOf(a);
	System.out.println(s);
	String l;
	Integer In= 345;
	l= In.toString();
	System.out.println(l);
	//
	C x = new C(), y = new C();
	x = y;
	x.setX(5);
	//y.setX(6);
	System.out.println(x.getX() + " et " +y.getX());

}
}