package tp6;

public class Testclone {
	public static void main(String args[]){
		
			Cellule x = new Cellule(); 
			
			x.afficher();
			Cellule y = (Cellule) x.clone(); 
			
			y.afficher();  
			
			Cellule a= new Cellule();
			a = (Cellule) x.clone();
			a.afficher();
			x.changeMe();
			x.afficher();
			y.afficher();
			}
			}

