package tp7;

public class TaPile implements Pile {
    private char[] tableau;

    public TaPile() {
        tableau = new char[MAX];
    }

    @Override
    public void empiler(char c) throws PilepleinException {
        if (pleine()) {
            throw new PilepleinException ("La pile est pleine.");
        }
        try {
			tableau[sommet()] = c;
		} catch (PilevideException e) {
			
			e.getMessage();
		}
    }

    @Override
    public char sommet() throws PilevideException {
        if (vide()) {
            throw new PilevideException ("La pile est vide.");
        }
        return tableau[taille() - 1];
    }

    @Override
    public void depiler ()throws PilevideException {
        if (vide()) {
            throw new  PilevideException ("La pile est vide.");
        }
        tableau[taille() - 1] = '\0';
    }

    @Override
    public boolean vide() {
        return taille() == 0;
    }

    @Override
    public boolean pleine() {
        return taille() == MAX;
    }

    private int taille() {
        int taille = 0;
        while (taille < MAX && tableau[taille] != '\0') {
            taille++;
        }
        return taille;
    }
}
