package tp7;

public class PilepleinException extends Exception {
	
	public  PilepleinException(String message) {
		super (message);
	}
}
