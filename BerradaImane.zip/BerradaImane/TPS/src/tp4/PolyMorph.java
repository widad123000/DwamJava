package tp4;

public class PolyMorph {

	public static void main(String[] args) {
		 Article[] chariot ;
		 chariot=new Article[3];
		  chariot[0]=new Article(1, "Pomme", 10, 100);
		  chariot[1]= new ArticleLuxe  (2, "iPhone", 200, 100);
		  chariot[2]=new Vetement(3, "Pull", 30, 100, "XL", "Vert");
		 
	        double montant = 0;

	        for (Article p : chariot) {
	            montant += p.prixTTC();
	        }

	        System.out.println(montant);

	}

}
