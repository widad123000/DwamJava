package tp4;

public class Test {

	public static void main(String[] args) {
		Article a=new Article();
		Article a2=new Article(1,"pomme",11,100);
		Article a3=new Article(a);
		 System.out.println("Article a : " + a.getnumero() + ", " + a.getarticlen() + ", " + a.getprix() + ", " + a.getqts());
		 System.out.println("Article a : " + a2.getnumero() + ", " + a2.getarticlen() + ", " + a2.getprix() + ", " + a2.getqts());
		 System.out.println("Article a : " + a3.getnumero() + ", " + a3.getarticlen() + ", " + a3.getprix() + ", " + a3.getqts());	
		

	}

}
