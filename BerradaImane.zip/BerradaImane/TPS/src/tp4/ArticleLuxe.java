package tp4;

public class ArticleLuxe extends Article {
    public ArticleLuxe(int numero, String articlen, double prixht, int qts) {
        super(numero, articlen, prixht, qts);
    }

    public double prixTTC() {
        return getprix() * 1.25; 
    }
}
