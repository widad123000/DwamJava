package tp2;

public class ExceptionPileUnderflow extends Exception {
	
		public  ExceptionPileUnderflow(String message) {
			super(message);
		}

}
