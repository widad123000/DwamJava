package tp8;
import tp4.Article;

public interface MonAppi   {
	public void print();

	public String convTexte();
	
	public int compare (Article o);
	
}
