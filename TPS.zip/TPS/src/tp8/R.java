package tp8;

import tp4.Article;

public class R extends Article implements MonAppi {

    public R(int numero, String designation, double prixHT, int qts) {
        super(numero, designation, prixHT, qts);
    }

    public void print() {
        System.out.println(convTexte());
    }
    public String convTexte() {
        return "{" + getnumero() + "," + getarticlen() + "," + getprix() + "," + getqts() + "}";
    }

    public int compare(Article o) {
      
        if (getnumero() > o.getnumero()) {
            return 1;
        } else if (getnumero() < o.getnumero()) {
            return -1;
        } else {
            return 0;
        }
    }
}
