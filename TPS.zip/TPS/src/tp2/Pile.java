package tp2;

public class Pile {

	static final int max=8;
	 int top;
	char[] t;
	int capacite;
	public Pile( int capacite){
		t=new char[max];
		top=-1;
		this.capacite=capacite;
				}
	public Pile( ) {}
	public boolean isPlein() {
        return top == max - 1;
    }
		public void implementer(char c) {
			if(!isPlein()) {
				t[++top]=c;
			}
			else {
				System.out.println("pile est pleine");}
			
		}
		public char pop() throws ExceptionPileUnderflow {
			if(top == -1) {
				throw new ExceptionPileUnderflow("debordement par bas (pile vide");
			}
			else	
			return t[top];
		}

		public char Sommet() {
	        
	            return t[top];
	       
	    }
		public void depiler() {
	        if (estVide()) {
	        	System.out.println("La pile est vide");
	            
	        } else 
	             top--;
	        
	    }
		public Boolean estVide() {
			 return top==-1;
				
		
				
			
			
		}
		public void afficher() {
	        for (int i = 0; i <= top; i++) {
	            System.out.println("" + t[i]);
	        }
	    }
	
	

}
