package tp2;

import java.util.Scanner;


public class Test {

	public static void main(String[] args) {
		Pile pile = new Pile();

		 
        pile.implementer('A');
        pile.implementer('B');
        pile.implementer('C');
        pile.implementer('k');
   

   
		System.out.println("Sommet de la pile : " + pile.Sommet());
	
		
	

   
   pile.depiler();
  
   pile.afficher();

  
   System.out.println("La pile est vide : " + pile.estVide());
		Pile p = new Pile(10) ;
		char c;
		 Scanner scanner = new Scanner(System.in);
		 System.out.println(" entrer c : (# pour terminer )");
		 c = scanner.next().charAt(0);
		 
		 while(c!='#')
		 {
			 p.implementer(c);
			 c = scanner.next().charAt(0);
			 
		 }
			 try {
				c = p.pop() ;
			} catch (ExceptionPileUnderflow e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 System.out.println(c);
			 
		 scanner.close();
	}

	}


