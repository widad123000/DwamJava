package tp7;

public interface Pile {
	final int MAX = 8;
	public void empiler(char c) throws PilepleinException;
	
	public char sommet()throws PilevideException;
	
	public void depiler() throws PilevideException;

	public boolean vide() ; 
	
	public boolean pleine();
	
}
