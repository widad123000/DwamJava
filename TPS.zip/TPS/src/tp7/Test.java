package tp7;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		MaPile pile = new MaPile();
        Scanner scanner = new Scanner(System.in);

        char c;
        do {
            System.out.print("Entrez un caractère (# pour terminer) : ");
            c= scanner.next().charAt(0);

            if (c != '#') {
                pile.empiler(c);
            }
        } while (c != '#');

        System.out.println("Caractères en ordre inverse : ");
        while (!pile.vide()) {
            try {
				System.out.print(pile.sommet() + " ");
				pile.depiler();}
			    catch (PilevideException e) {
				
				e.getMessage();}

        }
        //
       

        char n;

        TaPile [] a=new TaPile [4];
       



        for(int j=0;j<a.length;j++)
        { System.out.print("tab["+j+"]=");
          n= scanner.next().charAt(0);
          try {
        	  a[j] = new TaPile();
			a[j].empiler(n)  ;
		} catch (PilepleinException e) {
			
			e.printStackTrace();
		}
        }
        

       
    }

}
