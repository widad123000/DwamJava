package tp7;

public class MaPile implements Pile {
    private StringBuilder c;

    public MaPile() {
    	c = new StringBuilder(MAX);
    }

    @Override
    public void empiler(char s) {
        c.append(s);
    }

    @Override
    public char sommet() throws PilevideException{
        if (!vide()) {
            return c.charAt(c.length() - 1);
        } else {
            throw new PilevideException("La pile est vide.");
        }
    }

    @Override
    public void depiler() throws PilevideException {
        if (!vide()) {
            c.deleteCharAt(c.length() - 1);
        } else {
            throw new PilevideException ("La pile est vide.");
        }
    }

    @Override
    public boolean vide() {
        return c.length() == 0;
    }

    @Override
    public boolean pleine() {
        return c.length() == MAX;
    }
}
