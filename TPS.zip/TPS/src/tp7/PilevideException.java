package tp7;

public class PilevideException extends Exception {
	
		
  public PilevideException (String message)
	{
		super(message);
	}

}
