package tp6;

public class Cellule extends Object implements
Cloneable {
	
	int i = 0;
	int[] t = {1, 2};
	
	public Object clone(){
	try {
	return super.clone();
	}
	catch (CloneNotSupportedException e){
	throw new InternalError();}
	}
	
	public void afficher(){
		System.out.println(i +" "+ t[0]+" "+t[1]);
	}
	public void changeMe(){
		i = 10;
		t[0] = 11;
		t[1] = 12;
}}