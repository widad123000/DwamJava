package tp4;

public class Vetement extends Article {
    private String taille;
    private String couleur;

    public Vetement(int numero, String articlen, double prixht, int qts, String taille, String couleur) {
        super(numero, articlen, prixht, qts);
        this.taille = taille;
        this.couleur = couleur;
    }

    public String getTaille() {
        return taille;
    }

    public String getCouleur() {
        return couleur;
    }
}
