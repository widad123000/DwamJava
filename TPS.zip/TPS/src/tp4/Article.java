package tp4;

public class Article{
	private int numero;
	private String articlen;
	private double prixht;
	 private int qts;
	public Article(int numero ,String articlen,double prixht,int qts)
	{
		this.numero=numero;
		this.articlen=articlen;
		this.prixht=prixht;
		this.qts=qts;
	}
	public Article(Article a) 
	{
		this.articlen=a.articlen;
        this.numero=a.numero;
        this.prixht= a.prixht;
        this.qts=a.qts;
	
	}
	public Article() {
		this.numero=0;
		this.articlen="specimen";
		this.prixht=1.1;
		this.qts=222;
		
	}
	public int getnumero() {
        return numero;
    }

    public String getarticlen() {
        return articlen;
    }

    public double getprix() {
        return prixht;
    }

    public int getqts() {
        return qts;
    }

    public double prixTTC() {
        return getprix() * 1.25; 
    }
    //tp8
	public int compare(Article o) {
		
		return 0;
	}
	public void print() {
	
		
	}
	public String convTexte() {
		
		return null;
	}
	//
}
